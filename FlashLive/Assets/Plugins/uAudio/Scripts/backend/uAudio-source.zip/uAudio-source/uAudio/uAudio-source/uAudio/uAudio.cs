﻿using System;
using UnityEngine;
namespace uAudio.uAudio_backend
{
    // DO not make this IAudioPlayer an abstract class...!!!!
    public class uAudio : uAudio_backend.IAudioPlayer
    {
        #region vars
        //System.Action _PlaybackStopped;
        //public System.Action PlayBackStopped { get { return _PlaybackStopped; } set { _PlaybackStopped = value; } }
        Action<PlayBackState> _sendPlaybackState;

        public Action<PlayBackState> sendPlaybackState
        {
            get
            {
                return _sendPlaybackState;
            }

            set
            {
                _sendPlaybackState = value;
            }
        }
        public string targetFile;
        public string AudioTitle { get { return System.IO.Path.GetFileNameWithoutExtension(targetFile); } }
        string uAudio_backend.IAudioPlayer.current_TargetFile_Loaded
        {
            get
            { return targetFile; }
        }
        public UnityEngine.AudioSource _androidAudioSource;
        public void connectAndroidAudioSource(UnityEngine.AudioSource androidAudioSourceIN)
        {
            _androidAudioSource = androidAudioSourceIN;
        }
        public int SongLength { get { return WaveOutDevice.SongLength; } }
        IAudioPlayer __waveOutDevice;
        public uAudio_Windows uwa
        {
            get
            {
                uAudio_Windows temp = WaveOutDevice as uAudio_Windows;
                temp.sendPlaybackState = (uAudio_backend.PlayBackState c) => {

                    if (sendPlaybackState != null)
                        _sendPlaybackState(c);
                };

                return temp;
            }
        }

        public float[] getAudioData()
        {
            int length = (int)(uwa.audioPlayback.inputStream.Length);
            float[] samples = new float[length];
            uwa.audioPlayback.inputStream.Read(samples, 0, length);

            return samples;
        }

        public IAudioPlayer WaveOutDevice
        {
            get
            {
                if (__waveOutDevice == null)
                {
                        __waveOutDevice = new uAudio_Windows(this);

                        try
                        {
                            if (__waveOutDevice != null)
                            {
                                __waveOutDevice.Volume = _volume;

                            __waveOutDevice.sendPlaybackState = (uAudio_backend.PlayBackState c) => {

                                if(sendPlaybackState!=null)
                                _sendPlaybackState(c);
                            };          //LoadMainOutputStream();
                        }
                            else
                            {
                                System.Exception e = new Exception("uAudio Currently only works for UNITY_STANDALONE_WIN or UNITY_ANDROID. Change platforms if you want to use it.");
                                UnityEngine.Debug.LogException(e);
                            }
                        }
                        catch (System.Exception ex)
                        {
                            System.Exception e = new Exception("uAudio Currently only works for UNITY_STANDALONE_WIN or UNITY_ANDROID. Change platforms if you want to use it..", ex);
                            UnityEngine.Debug.LogException(e);
                        }
                }
                return __waveOutDevice;
            }
        }

        /// <summary>
        /// durata totale del brano in formato string MM:SS
        /// </summary>
        public TimeSpan TotalTime
        {
            get
            {
                if (__waveOutDevice != null)
                    return WaveOutDevice.TotalTime;
                else
                    return new TimeSpan();
            }
        }

        private float _volume = 1;
        public float Volume
        {
            get { return WaveOutDevice.Volume; }
            set
            {
                if (__waveOutDevice != null)
                    WaveOutDevice.Volume = value;
                _volume = value;
            }
        }

        public float Pan
        {
            get
            {
                if (__waveOutDevice != null)
                    return WaveOutDevice.Pan;
                else
                    return -1;
            }
            set
            {
                if (__waveOutDevice != null)
                    WaveOutDevice.Pan = value;
            }
        }

        public PlayBackState State
        {
            get
            {
                if (__waveOutDevice != null)
                    return (PlayBackState)WaveOutDevice.PlaybackState;
                else
                    return PlayBackState.Stopped;
            }
        }

        public bool IsPlaying
        {
            get { return State == PlayBackState.Playing; }
        }

        public PlayBackState PlaybackState
        {
            get { return State; }
        }

        public void ChangeCurrentTime(TimeSpan timeIN)
        {
            CurrentTime = timeIN;
        }

        public TimeSpan CurrentTime
        {
            get
            {
                if (__waveOutDevice != null)
                    return WaveOutDevice.CurrentTime;
                else
                    return new TimeSpan();
            }
            set
            {
                WaveOutDevice.CurrentTime = value;
            }
        }
        #endregion ---vars---

        #region con
        public void DoAudioClick()
        {
            //  if (waveOutDevice == null)
            SetAudioFile(targetFile);

            Play();
        }

        public bool LoadMainOutputStream()
        {
            if (!targetFile.StartsWith("http") && !System.IO.File.Exists(targetFile))
            {
                return false;
            }

            //if (__waveOutDevice != null)
            {
                //if(targetFile.StartsWith("http"))
                //   waveOutDevice.SetFile(targetFile);
                //else
                try
                {
                    if (WaveOutDevice.current_TargetFile_Loaded != targetFile)
                        WaveOutDevice.LoadFile(targetFile);
                    return true;
                }
                catch
                { return false; }
            }
            //else
            //    return false;
        }
        #endregion

        #region func
        public void Pause()
        {
            if (__waveOutDevice != null)
            {
                WaveOutDevice.Pause();
                if (sendPlaybackState != null)
                    _sendPlaybackState(uAudio_backend.PlayBackState.Paused);
            }
        }

        public void Play(System.TimeSpan? OffsetStart=null)
        {
            if (__waveOutDevice == null || WaveOutDevice.current_TargetFile_Loaded != targetFile)
            {
                LoadMainOutputStream();
            }

            if (__waveOutDevice != null)
            {
                if (WaveOutDevice.TotalTime > TimeSpan.Zero)
                {
                    WaveOutDevice.Volume = _volume;
                    if (WaveOutDevice.CurrentTime >= WaveOutDevice.TotalTime)
                    {
                        WaveOutDevice.CurrentTime = TimeSpan.Zero;
                    }

                    if (WaveOutDevice.PlaybackState != PlayBackState.Playing)
                    {
                        WaveOutDevice.Play();
                      

                            if (sendPlaybackState != null)
                                _sendPlaybackState(uAudio_backend.PlayBackState.Playing);
                    }
                    else
                    {
                        WaveOutDevice.Pause();
                        if (sendPlaybackState != null)
                            _sendPlaybackState(uAudio_backend.PlayBackState.Paused);

                    }
                }
                else
                    Debug.LogWarning("uAudio song not loaded. #u74ed6dsus");
            }
            else
                Debug.LogWarning("Could not start uAudio Play #987g8r");

            //try
            //{
            //    if(_sendPlaybackState!=null)
            //        _sendPlaybackState(PlayBackState.Playing);
            //}
            //catch
            //{
            //    Debug.LogWarning("  _sendPlaybackState(PlayBackState.Playing) #7gr6746457678gj68");
            //}
        }

        public void Stop()
        {
            if (__waveOutDevice != null)
            {
                WaveOutDevice.Stop();
                WaveOutDevice.Dispose();

                __waveOutDevice = null;
            }
        }

        public void LoadFile(string targetFileIN)
        {
            targetFile = targetFileIN;

            //LoadMainOutputStream();
        }
        public void SetFile(string targetFileIN)
        {
            targetFile = targetFileIN;

        }
        public void SetAudioFile(string FileName)
        {
            targetFile = FileName;
        }

        //private void _waveOutDevice_PlaybackStopped()
        //{
        //    if (PlayBackStopped != null)
        //        PlayBackStopped();
        //}

        public void reset()
        {
            WaveOutDevice.CurrentTime = TimeSpan.Zero;
        }
        #endregion ---func---

        #region Dispose
        #region ~con
        public void UnloadAudioNode()
        {
            if (__waveOutDevice != null)
            {
                __waveOutDevice.Dispose();
                __waveOutDevice = null;
            }
        }
        #endregion ---~con---

        bool isDisposed = false;

        public void Dispose()
        {
            if (isDisposed)
                return;

            isDisposed = true;
            try
            {
                if (__waveOutDevice != null)
                {
                    try
                    {
                        __waveOutDevice.Stop();
                    }
                    catch { UnityEngine.Debug.LogError("#a7vsif8as7fv"); }
                    __waveOutDevice.Dispose();
                    __waveOutDevice = null;
                }
            }
            catch {
                UnityEngine.Debug.LogError("#7fasfc78c7ac");
            }

            //_sendPlaybackState = null;
            targetFile = string.Empty;
        }
        #endregion ---Dispose---

        Action IAudioPlayer.SLEEP
        {
            get
            {
                Debug.LogWarning("SLEEP #h9dsvd");
                throw new NotImplementedException();
            }

            set
            {
                Debug.LogWarning("SLEEP #h9dsvd");
                throw new NotImplementedException();
            }
        }




        //public static void fireSafe(Action targetIN)
        //{
        //    //bool done = false;
        //    System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
        //    {
        //        try
        //        {
        //            targetIN();
        //            //done = true;
        //        }
        //        catch
        //        {
        //            UnityEngine.Debug.LogException(new Exception("Stop Audio #98dhs98dvhdv"));
        //        }
        //    }));
        //    t.IsBackground = true;
        //    t.Start();
        //    //while (!done)
        //    //{
        //    //    System.Threading.Thread.Sleep(10);
        //    //}
        //    t.Join(10);
        //}
    }
}