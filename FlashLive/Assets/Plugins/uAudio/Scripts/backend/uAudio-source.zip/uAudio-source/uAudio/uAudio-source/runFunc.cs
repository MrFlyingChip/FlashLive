﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace NAudio
//{
//    public class runFunc
//    {
//        public static void fireSafe(Action targetIN)
//        {

//            //bool done = false;
//            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
//            {
//                    targetIN();
//                    //done = true;
              
//            }));
//            t.IsBackground = true;
//            t.Start();
//            //while (!done)
//            //{
//            //    System.Threading.Thread.Sleep(10);
//            //}
//            t.Join(10);
//        }
//    }
//}
