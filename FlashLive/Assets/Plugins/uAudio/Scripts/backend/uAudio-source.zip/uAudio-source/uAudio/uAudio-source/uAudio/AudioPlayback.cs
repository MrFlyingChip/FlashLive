﻿using System;
using NAudio.Wave;

namespace uAudio.uAudio_backend
{
    public class AudioPlayback : IDisposable
    {
        public IWavePlayer playbackDevice;
        private WaveStream fileStream;
        public AudioFileReader inputStream;
        //SampleAggregator aggregator;

        public Action<string> logError;
        float _volume;
        public float Volume
        {
            get
            {
                if (inputStream != null)
                    return inputStream.Volume;
                else
                    return _volume;
            }
            set
            {
                if (inputStream != null)
                    inputStream.Volume = value;

                _volume = value;
            }
        }
        public void Load(string fileName)
        {
            EnsureDeviceCreated();
            OpenFile(fileName);
        }

        private void CloseFile()
        {
            if (fileStream != null)
            {
                fileStream.Dispose();
                fileStream = null;
            }
        }

        private void OpenFile(string fileName)
        {
            try
            {
                inputStream = new AudioFileReader(fileName);
                inputStream.Volume = _volume;
                fileStream = inputStream;
                //aggregator = new SampleAggregator(inputStream);
                //aggregator.NotificationCount = inputStream.WaveFormat.SampleRate / 100;
                //aggregator.PerformFFT = true;
                //aggregator.FftCalculated += (s, a) => OnFftCalculated(a);
                //aggregator.MaximumCalculated += (s, a) => OnMaximumCalculated(a);
                playbackDevice.Init(inputStream);
            }
            catch
            {
                if (logError != null)
                    logError("uAudio : Problem opening file #uisvdds");
                CloseFile();
            }
        }

        private void EnsureDeviceCreated()
        {
            if (playbackDevice == null)
            {
                CreateDevice();
            }
        }

        Action<PlayBackState> _sendPlaybackState;
        public Action<PlayBackState> sendPlaybackState
        {
            get
            {
                return _sendPlaybackState;
            }

            set
            {
                _sendPlaybackState = value;
            }
        }
        private void CreateDevice()
        {
            playbackDevice = new WaveOut();
            playbackDevice.PlaybackStopped += PlaybackDevice_PlaybackStopped;
        }

        private void PlaybackDevice_PlaybackStopped(object sender, StoppedEventArgs e)
        {
            if(sendPlaybackState!=null)
            {
                sendPlaybackState(PlayBackState.Stopped);
            }
        }

        public void Play(System.TimeSpan? OffsetStart = null)
        {
            if (playbackDevice != null && fileStream != null && playbackDevice.PlaybackState != PlaybackState.Playing)
            {
                playbackDevice.Play();

                if (sendPlaybackState != null)
                {
                    sendPlaybackState(PlayBackState.Playing);
                }
                //                if(OffsetStart.HasValue)
                //                {
                //                    // hack hack
                //(                  (WaveOut)  playbackDevice).
                //                       fsdfs
                //                }
            }
        }

        public void Pause()
        {
            if (playbackDevice != null)
            {
                if (playbackDevice.PlaybackState == PlaybackState.Playing)
                {
                    playbackDevice.Pause();

                    if (sendPlaybackState != null)
                        sendPlaybackState(PlayBackState.Paused);
                }
                else
                  if (playbackDevice.PlaybackState == PlaybackState.Paused)
                    {
                        playbackDevice.Resume();

                        if (sendPlaybackState != null)
                            sendPlaybackState(PlayBackState.Playing);
                    }
            }
        }

        public void Stop()
        {
            try
            {
                if (playbackDevice != null)
                {
                    playbackDevice.Stop();
                    CloseFile();
                }

                if (fileStream != null)
                {
                    fileStream.Position = 0;
                }

                if (sendPlaybackState != null)
                    sendPlaybackState(PlayBackState.Stopped);
            }
            catch (System.Exception ex)
            {
                if (logError != null)
                {
                    logError("error: " + ex.Message);
                    logError("AudioPlayback - stop #bh84b55b5 ");
                }
            }
        }

        public void Dispose()
        {
            try
            {
                Stop();
                CloseFile();
            }
            catch
            {
                if (logError != null)
                    logError("#98cg98vdfsvsdf");
            }
            try
            {
                if (playbackDevice != null)
                {
                    playbackDevice.Dispose();
                    playbackDevice = null;
                }
            }
            catch
            {
                if (logError != null)
                    logError("#h35j3h56jn67j");
            }
            //try
            //{
            //    aggregator.Dispose();
            //    aggregator = null;
            //}
            //catch
            //{
            //    if (logError != null)
            //        logError("#65j4657jn6t7j");
            //}
        }
    }
}